//
//  ZYFristViewController.m
//  WeiBoCamer
//
//  Created by Apple on 2017/6/29.
//  Copyright © 2017年 Apple. All rights reserved.
//
#define W  [UIScreen mainScreen].bounds.size.width
#define H  [UIScreen mainScreen].bounds.size.height
#import "ZYFristViewController.h"
#import "ZYFisrtSubViewController.h"
#import "ZYStoryViewController.h"
@interface ZYFristViewController ()<UIScrollViewDelegate>
@property(nonatomic,strong) UIScrollView *scrollView;
@end

@implementation ZYFristViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Frist";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.scrollView];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self addChildViewControllers];
    // Do any additional setup after loading the view.
}
-(void)addChildViewControllers{
    ZYFisrtSubViewController *fisrtSubVC = [[ZYFisrtSubViewController alloc]init];
    fisrtSubVC.view.frame = CGRectMake(W, 0, W, H);
    [self.scrollView addSubview:fisrtSubVC.view];
    [self addChildViewController:fisrtSubVC];
    
    ZYStoryViewController *storyVC = [[ZYStoryViewController alloc]init];
    [self.scrollView addSubview:storyVC.view];
    
    [self addChildViewController:storyVC];
    
    
}
-(UIScrollView *)scrollView {
    if (_scrollView == nil) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0,W,H)];
        _scrollView.delegate = self;
        _scrollView.contentSize =CGSizeMake(2*W, H);
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.contentOffset = CGPointMake(W, 0);
        [_scrollView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    }
    return _scrollView;
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if (object == self.scrollView) {
        if ([keyPath isEqualToString: @"contentOffset"]) {
            CGFloat offsetX = self.scrollView.contentOffset.x;
            
            if (offsetX<W) {
                self.tabBarController.tabBar.transform = CGAffineTransformMakeTranslation(W-offsetX, 0);
                self.navigationController.navigationBar.transform = CGAffineTransformMakeTranslation(W-offsetX, 0);
            }else{
            
                self.tabBarController.tabBar.transform =  CGAffineTransformIdentity;
                self.navigationController.navigationBar.transform = CGAffineTransformIdentity;
            }
            
            
        }
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
