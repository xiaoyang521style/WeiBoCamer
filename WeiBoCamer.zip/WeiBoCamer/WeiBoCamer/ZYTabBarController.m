//
//  ZYTabBarController.m
//  WeiBoCamer
//
//  Created by Apple on 2017/6/29.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "ZYTabBarController.h"
#import "ZYFristViewController.h"
#import "ZYSecondViewController.h"
@interface ZYTabBarController ()

@end

@implementation ZYTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    ZYFristViewController *fristVC = [[ZYFristViewController alloc]init];
   
    UINavigationController *fristNaVC = [[UINavigationController alloc]initWithRootViewController:fristVC];
     fristNaVC.tabBarItem.title = @"frist";
    ZYSecondViewController *secondVC = [[ZYSecondViewController alloc]init];

    UINavigationController *secondNaVC = [[UINavigationController alloc]initWithRootViewController:secondVC];
    secondNaVC.tabBarItem.title = @"second";
    self.viewControllers = @[fristNaVC,secondNaVC];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
