//
//  ZYFisrtSubViewController.m
//  WeiBoCamer
//
//  Created by Apple on 2017/6/29.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "ZYFisrtSubViewController.h"

@interface ZYFisrtSubViewController ()

@end

@implementation ZYFisrtSubViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor yellowColor];
    UILabel *la = [[UILabel alloc]initWithFrame:self.view.frame];
    la.textAlignment = NSTextAlignmentCenter;
    la.text = @"左滑动";
    [self.view addSubview:la];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
